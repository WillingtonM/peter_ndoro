<?php


$processed_events   = get_events_processed();

$is_admin   = is_admin_check();
