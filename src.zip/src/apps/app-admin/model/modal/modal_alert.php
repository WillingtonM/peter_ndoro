<?php require_once $config['PARSERS_PATH'] . 'modal' . DS . 'alert_action.php' ?>

