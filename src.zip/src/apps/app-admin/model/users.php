<?php

$is_admin   = is_admin_check();
