<?php

redirect_to('media?tab=podcast');
