<?php


$data         = array('error' => false);
$intval       = 9;
$artcl_count  = 1;
$array_count  = 0;
$tabbs_count  = 0;
