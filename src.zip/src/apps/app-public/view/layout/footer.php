<!-- Copyright -->
<div class="col-12 text-center pb-3">
    <small class="text-center me-1">Copyright © <?= date("Y") ?>, <?= $_ENV['COMPANY_NAME'] ?> </small> <span class="me-1" style="font-size: 1rem;"> &middot;</span>
    <small class="me-1">
        <a type="button" class="text-xs" style="color: #999" data-bs-toggle="modal" data-bs-target="#modalSupport">Login</a>
    </small> <span class="me-1" style="font-size: 1rem;"> &middot; </span>
    <small class=""> <i class="me-1">Powered by</i> <a class="alt_dflt/ text-xs" style="color: #999" target="_blank" href="http://tda.tralon.co.za/">TDA </a> </small>
</div>