            </div> <!-- end of modal-body -->

            <!-- footer -->
            <?php if (isset($footer_content) && !empty($footer_content)) : ?>
                <div class="modal-footer px-3 py-1" style="border-top: none;">
                    <?= $footer_content ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
