<div class="col p-3 border-radius-xl mb-2 text-center">
    <p class="text-sm">
        Peter Ndoro's exceptional skills as a Master of Ceremonies make him the perfect choice to host your event. 
        With his captivating presence, wit, and ability to connect with the audience, Peter sets the tone and keeps the energy alive throughout the program. 
        From corporate galas to award ceremonies, product launches, and fundraisers, Peter Ndoro's expertise as an MC guarantees a seamless and engaging event.
    </p>
</div>