<div class="col-12 text-center mb-3">
    <small style="color: #999; font-size: .8rem;">
        Lorem ipsum dolor sit amet
    </small>
</div>


<div class="col shadow bg-white p-3 border-radius-xl mb-2">
    <span class="font-weight-bolder"> Lorem ipsum dolor sit amet </span>

    <p class="text-sm">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
    </p>
</div>