<div class="col p-3 border-radius-xl mb-2">
    <p class="text-sm">
        As a Conference Speaker, Peter Ndoro brings a wealth of knowledge and insights gained from his extensive experience in the media industry. 
        With his engaging speaking style, Peter delivers impactful presentations that resonate with audiences. 
        He can cover a wide range of topics, including media and broadcasting, entrepreneurship, leadership, motivation, and personal development. 
        Peter Ndoro's eloquence and ability to connect with diverse audiences make him a sought-after conference speaker.
    </p>
</div>